# -*- coding: utf-8 -*-


import pandas as pd
import numpy as np
dataset = pd.read_csv(r'C:\Users\GITEX\Desktop\Mobile_price.csv')
dataset.dropna(inplace = True)
x= dataset.iloc[:, :-1].values
y= dataset.iloc[:, 20].values

from sklearn.svm import SVC   
clf = SVC(kernel='rbf')
clf.fit(x, y) 
y_pred = clf.predict(x)
from sklearn import metrics
print("Accuracy:",metrics.accuracy_score(y, y_pred))
x= dataset.iloc[:, :-1].values
y= dataset.iloc[:, 20].values
from sklearn.preprocessing import MinMaxScaler
scale = MinMaxScaler()
x = scale.fit_transform(x)
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y
                                                    , test_size=0.30)
from sklearn.svm import SVC   
clf = SVC(kernel='rbf')
clf.fit(x_test, y_test) 
y_pred = clf.predict(x_test)
from sklearn import metrics
print("Accuracy after scale:",metrics.accuracy_score(y_test, y_pred))

dataset = pd.read_csv(r'C:\Users\GITEX\Desktop\Mobile_price.csv')
dataset.dropna(inplace = True)
s = dataset.px_height
p = dataset.px_width
masahat = np.multiply(s, p)
dataset['masahat'] = masahat
x= dataset.iloc[:, :-1].values
y= dataset.iloc[:, 20].values
clf = SVC(kernel='rbf')
clf.fit(x, y) 
y_pred = clf.predict(x)
print("Accuracy with masahat:",metrics.accuracy_score(y, y_pred))


a = dataset.battery_power
a = list(a)
a.sort()
new = []
first = a[:666]
sec = a[666 : 1333]
third = a[1333:]
for i in range(1, 666):
    new.append(np.mean(first))
for i in range(666, 1333):
    new.append(np.mean(sec))
for i in range(1333,1980):
    new.append(np.mean(third))
a = dataset.price_range
dataset.drop(['battery_power', 'masahat', 'price_range'], axis = 1, inplace = True)
dataset['binning_battery']= new
dataset['price'] = a
x= dataset.iloc[:, :-1].values
y= dataset.iloc[:, 20].values
clf = SVC(kernel='rbf')
clf.fit(x, y) 
y_pred = clf.predict(x)
print("Accuracy binning:",metrics.accuracy_score(y, y_pred))


