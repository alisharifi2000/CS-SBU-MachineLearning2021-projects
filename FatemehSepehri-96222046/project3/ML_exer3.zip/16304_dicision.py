# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score
dataset = pd.read_csv(r'C:\Users\GITEX\Desktop\Mobile_price.csv')
dataset.dropna(inplace = True)
x= dataset.iloc[:, :-1].values
y= dataset.iloc[:, 20].values

from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier(criterion = 'entropy', max_depth = 3)
clf.fit(x, y)
pred_values = clf.predict(x)
print("Accuracy:",accuracy_score(pred_values, y))
