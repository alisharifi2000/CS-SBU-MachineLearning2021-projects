# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score
dataset = pd.read_csv(r'C:\Users\GITEX\Desktop\Mobile_price.csv')
dataset.dropna(inplace = True)
x= dataset.iloc[:, :-1].values
y= dataset.iloc[:, 20].values
from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(criterion='entropy', n_estimators=50)

classifier.fit(x, y)
y_pred = classifier.predict(x)
print("Accuracy:",accuracy_score(y_pred, y))
